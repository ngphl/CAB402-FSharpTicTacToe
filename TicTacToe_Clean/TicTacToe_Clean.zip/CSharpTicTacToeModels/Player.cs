﻿namespace QUT.CSharpTicTacToe
{
    public enum Player
    {
        Cross,
        Nought
    }
}
